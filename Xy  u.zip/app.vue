<template>
  <TheHeader></TheHeader>

  <div>
    <NuxtPage />
  </div>

  <TheFooter></TheFooter>
</template>

<template>
    <div class="terms">
        <h1>пользовательское соглашение</h1>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>

    </div>
</template>
<script setup>
useSeoMeta({
    title: 'Пользовательское соглашение | Themes',
    ogTitle: 'Пользовательское соглашение | Themes',
    description: 'Пользовательское соглашение | Themes',
    ogDescription: 'Пользовательское соглашение | Themes',
})
</script>
<style scoped>
.terms p {
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: 140%;
    font-family: var(--int);
    color: #000;
}

.terms h1 {
    font-size: 56px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
    text-transform: uppercase;
    font-family: var(--int);
    color: #000;
}

.terms {
    padding: 140px 100px 72px;
}

@media (max-width: 1440px) {
    .terms {
        padding: 140px 50px 72px;
    }
}

@media (max-width: 1024px) {
    .terms {
        padding: 140px 20px 50px;
    }

    .terms p {
        font-size: 16px;
        font-style: normal;
        font-weight: 400;
        line-height: 140%;
        font-family: var(--int);
        color: #000;
    }

    .terms h1 {
        text-align: center;
        font-size: 20px;
        font-style: normal;
        font-weight: 500;
        line-height: normal;
        text-transform: uppercase;
        font-family: var(--int);
        color: #000;
    }
}
</style>
<template>
    <div class="polytics">
        <h1>Политика конфиденциальности</h1>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ex incidunt velit consequatur eligendi error, odio rem
            quisquam laudantium aut, voluptate asperiores. Excepturi similique iure, quidem repudiandae maxime incidunt
            aperiam blanditiis!</p>

    </div>
</template>
<script setup>
useSeoMeta({
    title: 'Политика конфиденциальности | Themes',
    ogTitle: 'Политика конфиденциальности | Themes',
    description: 'Политика конфиденциальности | Themes',
    ogDescription: 'Политика конфиденциальности | Themes',
})
</script>
<style scoped>
.polytics p {
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: 140%;
    font-family: var(--int);
    color: #000;
}

.polytics h1 {
    font-size: 56px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
    text-transform: uppercase;
    font-family: var(--int);
    color: #000;
}

.polytics {
    padding: 140px 100px 72px;
}

@media (max-width: 1440px) {
    .polytics {
        padding: 140px 50px 72px;
    }
}

@media (max-width: 1024px) {
    .polytics {
        padding: 140px 20px 50px;
    }

    .polytics p {
        font-size: 16px;
        font-style: normal;
        font-weight: 400;
        line-height: 140%;
        font-family: var(--int);
        color: #000;
    }

    .polytics h1 {
        text-align: center;
        font-size: 20px;
        font-style: normal;
        font-weight: 500;
        line-height: normal;
        text-transform: uppercase;
        font-family: var(--int);
        color: #000;
    }
}
</style>
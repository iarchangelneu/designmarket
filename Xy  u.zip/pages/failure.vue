<template>
    <div class="succes">
        <div class="text-center">
            <h1>(Не)Успех</h1>
        </div>
    </div>
</template>
<style scoped>
.succes {
    padding: 140px 100px 72px;
}
</style>